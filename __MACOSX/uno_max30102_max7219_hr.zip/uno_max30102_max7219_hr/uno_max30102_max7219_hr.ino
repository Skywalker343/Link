/*
 * Arduino UNO + MAX30102 + MAX7219 8x8
 *
 * 手指放上 → 点阵全亮（不闪烁）→ 每 10 秒串口平均心率 + 图案
 *
 * MAX30102: SDA→A4  SCL→A5
 * MAX7219:  DIN→D11  CS→D10  CLK→D13
 *
 * 库：LedControl、SoftwareWire
 */

#include <Wire.h>
#include <LedControl.h>
#include "MAX30102_SoftWire.h"
#include "heartRate.h"

#define PIN_MAX7219_DIN 11
#define PIN_MAX7219_CS 10
#define PIN_MAX7219_CLK 13

#define IR_FINGER_ON 45000L
#define IR_FINGER_OFF 35000L
#define FINGER_LEAVE_MS 1500UL
#define MEASURE_PERIOD_MS 10000UL
#define PERIOD_BPM_CAP 40
#define STATUS_PRINT_MS 1000UL

// LedControl(数据 DIN, 时钟 CLK, 片选 CS, 芯片数)
LedControl matrix(PIN_MAX7219_DIN, PIN_MAX7219_CLK, PIN_MAX7219_CS, 1);
MAX30102_SoftWire particle;

static uint16_t periodBpms[PERIOD_BPM_CAP];
static uint8_t periodCount = 0;

static unsigned long lastBeatMs = 0;
static unsigned long periodStartMs = 0;
static unsigned long irLowSince = 0;
static unsigned long lastStatusMs = 0;
static int32_t lastIr = 0;
static bool sessionActive = false;
static bool showingFullBright = false;
static int displayedBpm = 0;

enum Shape : uint8_t {
  SHAPE_NONE = 0,
  SHAPE_CIRCLE,
  SHAPE_SQUARE,
  SHAPE_TRIANGLE,
  SHAPE_STAR
};

// 8x8 图案（每个字节是一行，从上到下；bit7 是最左列）
const byte BMP_CIRCLE[8] = {
    0b00111100, 0b01000010, 0b10000001, 0b10000001,
    0b10000001, 0b10000001, 0b01000010, 0b00111100};

const byte BMP_SQUARE[8] = {
    0b11111111, 0b10000001, 0b10000001, 0b10000001,
    0b10000001, 0b10000001, 0b10000001, 0b11111111};

const byte BMP_TRIANGLE[8] = {
    0b00000001, 0b00000011, 0b00000101, 0b00001001,
    0b00010001, 0b00100001, 0b01000001, 0b11111111};

const byte BMP_STAR[8] = {
    0b00011000, 0b10011001, 0b01011010, 0b00111100,
    0b11111111, 0b00111100, 0b01011010, 0b10011001};

static void matrixInit(void) {
  matrix.shutdown(0, false);
  matrix.setIntensity(0, 5);
  matrix.setScanLimit(0, 7);
  clearMatrix();
}

static void matrixAllOn(void) {
  for (uint8_t r = 0; r < 8; r++) {
    matrix.setRow(0, r, 0xFF);
  }
  showingFullBright = true;
}

static void clearMatrix(void) {
  for (uint8_t r = 0; r < 8; r++) {
    matrix.setRow(0, r, 0x00);
  }
  showingFullBright = false;
}

static void drawPattern(const uint8_t *rows) {
  for (uint8_t r = 0; r < 8; r++) {
    matrix.setRow(0, r, rows[r]);
  }
  showingFullBright = false;
}

static void matrixBootTest(void) {
  matrixAllOn();
  delay(600);
  clearMatrix();
}

static Shape shapeForBpm(int bpm) {
  if (bpm < 50) {
    return SHAPE_NONE;
  }
  if (bpm < 70) {
    return SHAPE_CIRCLE;
  }
  if (bpm < 80) {
    return SHAPE_SQUARE;
  }
  if (bpm < 100) {
    return SHAPE_TRIANGLE;
  }
  return SHAPE_STAR;
}

static const char *shapeName(Shape s) {
  switch (s) {
    case SHAPE_CIRCLE:
      return "圆";
    case SHAPE_SQUARE:
      return "方";
    case SHAPE_TRIANGLE:
      return "三角";
    case SHAPE_STAR:
      return "星";
    default:
      return "-";
  }
}

static void showShape(Shape s) {
  switch (s) {
    case SHAPE_CIRCLE:
      drawPattern(BMP_CIRCLE);
      break;
    case SHAPE_SQUARE:
      drawPattern(BMP_SQUARE);
      break;
    case SHAPE_TRIANGLE:
      drawPattern(BMP_TRIANGLE);
      break;
    case SHAPE_STAR:
      drawPattern(BMP_STAR);
      break;
    default:
      clearMatrix();
      break;
  }
}

static void periodReset(void) {
  periodCount = 0;
}

static void periodPush(uint16_t bpm) {
  if (periodCount < PERIOD_BPM_CAP) {
    periodBpms[periodCount++] = bpm;
  }
}

static int periodAverage(void) {
  if (periodCount == 0) {
    return 0;
  }
  unsigned long sum = 0;
  for (uint8_t i = 0; i < periodCount; i++) {
    sum += periodBpms[i];
  }
  return (int)(sum / periodCount);
}

static void resetSession(void) {
  sessionActive = false;
  showingFullBright = false;
  periodReset();
  lastBeatMs = 0;
  displayedBpm = 0;
  periodStartMs = 0;
  irLowSince = 0;
  clearMatrix();
}

static void startSession(void) {
  periodReset();
  lastBeatMs = 0;
  displayedBpm = 0;
  periodStartMs = millis();
  irLowSince = 0;
  sessionActive = true;
  matrixAllOn();
  Serial.println(F("\n>>> 手指已放上：点阵全亮，10 秒后输出平均心率"));
}

static void onBeatDetected(void) {
  const unsigned long now = millis();
  const unsigned long delta = (lastBeatMs == 0) ? 0 : (now - lastBeatMs);
  lastBeatMs = now;

  if (delta < 300 || delta > 2500) {
    return;
  }

  const float bpmInst = 60.0f / (delta / 1000.0f);
  if (bpmInst > 20.0f && bpmInst < 255.0f) {
    periodPush((uint16_t)(bpmInst + 0.5f));
  }
}

static void processIrSample(int32_t irValue) {
  if (!sessionActive || irValue < (int32_t)IR_FINGER_OFF) {
    return;
  }
  if (checkForBeat(irValue)) {
    onBeatDetected();
  }
}

static unsigned long periodRemainMs(void) {
  const unsigned long e = millis() - periodStartMs;
  return (e >= MEASURE_PERIOD_MS) ? 0 : (MEASURE_PERIOD_MS - e);
}

static void finishPeriod(void) {
  const int avg = periodAverage();
  periodReset();
  periodStartMs = millis();

  if (avg > 0) {
    displayedBpm = avg;
    const Shape s = shapeForBpm(avg);
    Serial.print(F("\n【10秒平均心率】 "));
    Serial.print(avg);
    Serial.print(F(" BPM"));
    if (s != SHAPE_NONE) {
      Serial.print(F("  图案:"));
      Serial.println(shapeName(s));
      showShape(s);
    } else {
      Serial.println(F("  (<50 不显示图案)"));
      clearMatrix();
    }
  } else {
    displayedBpm = 0;
    Serial.println(F("\n【10秒平均】未检测到心跳，继续全亮采样"));
    matrixAllOn();
  }

  Serial.println(F("--- 下一周期 10 秒 ---"));
}

static void printStatus(void) {
  Serial.print(F("[采样] 剩 "));
  Serial.print((periodRemainMs() + 999) / 1000);
  Serial.print(F("s  IR="));
  Serial.print(lastIr);
  Serial.print(F("  心跳数="));
  Serial.println(periodCount);
}

static bool updateFingerSession(void) {
  const bool irHigh = (lastIr >= (int32_t)IR_FINGER_ON);
  const bool irLow = (lastIr < (int32_t)IR_FINGER_OFF);

  if (irHigh) {
    irLowSince = 0;
    if (!sessionActive) {
      startSession();
    }
    return true;
  }

  if (!sessionActive) {
    return false;
  }

  if (!irLow) {
    return true;
  }

  if (irLowSince == 0) {
    irLowSince = millis();
  }
  if (millis() - irLowSince < FINGER_LEAVE_MS) {
    return true;
  }

  Serial.println(F("\n手指离开 → 结束"));
  resetSession();
  return false;
}

void setup() {
  Serial.begin(115200);
#if defined(USBCON)
  unsigned long t0 = millis();
  while (!Serial && (millis() - t0 < 3000)) {
    delay(10);
  }
#endif
  delay(200);

  Serial.println(F("\n=== MAX30102 + MAX7219 ==="));
  Serial.println(F("MAX7219: DIN=11  CS=10  CLK=13"));
  Serial.println(F("上电全亮约 0.6 秒；手指放上后再全亮 10 秒"));
  Serial.println(F("串口 115200\n"));

  matrixInit();
  matrixBootTest();

  Wire.begin();
  if (!particle.begin(Wire, I2C_SPEED_STANDARD)) {
    Serial.println(F("[错误] MAX30102 未找到"));
    while (true) {
      delay(500);
    }
  }

  particle.setup(0x1F, 4, 2, 100, 411, 4096);
  particle.setPulseAmplitudeRed(0x0A);
  particle.setPulseAmplitudeIR(0x1F);

  resetSession();
}

void loop() {
  particle.check();

  while (particle.available()) {
    lastIr = (int32_t)particle.getFIFOIR();
    particle.nextSample();
    processIrSample(lastIr);
  }

  if (!particle.available()) {
    lastIr = (int32_t)particle.getIR();
  }

  updateFingerSession();

  if (!sessionActive) {
    return;
  }

  // 全亮期间不再重复写点阵，避免闪烁
  if (millis() - lastStatusMs >= STATUS_PRINT_MS) {
    lastStatusMs = millis();
    printStatus();
  }

  if (millis() - periodStartMs >= MEASURE_PERIOD_MS) {
    finishPeriod();
  }
}
